#!/usr/bin/env python3
"""
POC-AD-1: Standalone Fire Tools Test
Tests fire data integration tools without requiring full ADK framework
"""

import os
import sys
import logging
from typing import Dict

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_fire_query_templates() -> bool:
    """Test fire query templates independently"""
    logger.info("🧪 Testing fire query templates...")
    
    try:
        # Import fire query templates function directly
        from fire_tools_simple import get_fire_query_templates, format_fire_query
        
        templates = get_fire_query_templates()
        
        expected_templates = [
            'all_stations', 'high_risk_stations', 'stations_by_state',
            'latest_fire_danger', 'extreme_fire_danger', 'fire_danger_trends',
            'weather_fire_correlation', 'dry_conditions_analysis',
            'fuel_moisture_analysis', 'geographic_fire_risk_summary'
        ]
        
        for template_name in expected_templates:
            if template_name not in templates:
                logger.error(f"❌ Missing template: {template_name}")
                return False
            
            # Test template formatting
            query = format_fire_query(template_name, "test_project")
            if "{project}" in query:
                logger.error(f"❌ Template {template_name} not properly formatted")
                return False
            
            # Validate SQL structure
            if not query.strip().upper().startswith('SELECT'):
                logger.error(f"❌ Template {template_name} doesn't start with SELECT")
                return False
            
            if 'poc_fire_data' not in query:
                logger.error(f"❌ Template {template_name} doesn't reference fire dataset")
                return False
            
            logger.info(f"✅ Template {template_name}: Valid ({len(query)} chars)")
        
        logger.info(f"✅ All {len(expected_templates)} query templates working")
        return True
        
    except ImportError as e:
        logger.error(f"❌ Could not import fire_tools: {e}")
        return False
    except Exception as e:
        logger.error(f"❌ Query template testing failed: {e}")
        return False

def test_fire_query_suggestions() -> bool:
    """Test fire query suggestions"""
    logger.info("🧪 Testing fire query suggestions...")
    
    try:
        from fire_tools_simple import get_fire_query_suggestions
        
        test_cases = [
            ("show me all weather stations", ['all_stations', 'stations_by_state']),
            ("what's the current fire danger?", ['latest_fire_danger', 'extreme_fire_danger', 'fire_danger_trends']),
            ("high elevation fire risk", ['high_risk_stations']),
            ("weather and fire correlation", ['weather_fire_correlation', 'dry_conditions_analysis']),
            ("fuel moisture analysis", ['fuel_moisture_analysis']),
            ("regional fire risk summary", ['geographic_fire_risk_summary', 'stations_by_state'])
        ]
        
        for user_query, expected_suggestions in test_cases:
            suggestions = get_fire_query_suggestions(user_query)
            
            # Check if at least one expected suggestion is present
            found_match = any(suggestion in suggestions for suggestion in expected_suggestions)
            
            if found_match:
                logger.info(f"✅ '{user_query}' → {suggestions}")
            else:
                logger.warning(f"⚠️ '{user_query}' → {suggestions} (expected one of {expected_suggestions})")
        
        logger.info("✅ Query suggestion testing complete")
        return True
        
    except Exception as e:
        logger.error(f"❌ Query suggestion testing failed: {e}")
        return False

def test_database_enhancement() -> bool:
    """Test database settings enhancement"""
    logger.info("🧪 Testing database settings enhancement...")
    
    try:
        from fire_tools_simple import enhance_database_settings_with_fire_data
        
        # Mock existing database settings
        existing_settings = {
            "bq_project_id": "test_project",
            "bq_dataset_id": "test_dataset", 
            "bq_ddl_schema": "-- Existing schema\nCREATE TABLE test_table (id INT64);"
        }
        
        # Enhance with fire data
        enhanced_settings = enhance_database_settings_with_fire_data(existing_settings)
        
        # Check enhancement
        required_keys = ['fire_enabled', 'combined_schema', 'fire_dataset_id', 'fire_tables']
        
        for key in required_keys:
            if key not in enhanced_settings:
                logger.error(f"❌ Missing enhanced key: {key}")
                return False
        
        # Check schema combination
        combined_schema = enhanced_settings['combined_schema']
        if "-- Existing schema" not in combined_schema:
            logger.error("❌ Original schema not preserved")
            return False
        
        logger.info("✅ Database enhancement working correctly")
        logger.info(f"   Enhanced keys: {len(enhanced_settings)}")
        logger.info(f"   Combined schema: {len(combined_schema)} characters")
        logger.info(f"   Fire enabled: {enhanced_settings['fire_enabled']}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Database enhancement testing failed: {e}")
        return False

def test_sample_fire_queries() -> bool:
    """Test sample fire queries for common use cases"""
    logger.info("🧪 Testing sample fire queries...")
    
    try:
        from fire_tools_simple import format_fire_query
        
        # Test key fire queries
        sample_queries = [
            'all_stations',
            'latest_fire_danger',
            'extreme_fire_danger', 
            'weather_fire_correlation',
            'fuel_moisture_analysis'
        ]
        
        project_id = "test_project"
        
        for query_name in sample_queries:
            query = format_fire_query(query_name, project_id)
            
            # Validate query structure
            query_upper = query.upper()
            
            # Check for essential SQL components
            if 'SELECT' not in query_upper:
                logger.error(f"❌ Query {query_name} missing SELECT")
                return False
            
            if 'FROM' not in query_upper:
                logger.error(f"❌ Query {query_name} missing FROM")
                return False
            
            if 'poc_fire_data' not in query:
                logger.error(f"❌ Query {query_name} doesn't reference fire dataset")
                return False
            
            if project_id not in query:
                logger.error(f"❌ Query {query_name} doesn't include project ID")
                return False
            
            # Count expected tables for joins
            fire_tables = ['nfdr_daily_summary', 'station_metadata', 'weather_daily_summary', 'fuel_samples']
            table_count = sum(1 for table in fire_tables if table in query)
            
            logger.info(f"✅ Query {query_name}: Valid SQL, {table_count} fire tables, {len(query)} chars")
        
        logger.info("✅ All sample fire queries are valid")
        return True
        
    except Exception as e:
        logger.error(f"❌ Sample query testing failed: {e}")
        return False

def run_standalone_tests() -> Dict[str, bool]:
    """Run standalone fire tools tests"""
    logger.info("🚀 Starting standalone fire tools tests...")
    logger.info("=" * 60)
    
    tests = [
        ("Fire Query Templates", test_fire_query_templates),
        ("Query Suggestions", test_fire_query_suggestions),
        ("Database Enhancement", test_database_enhancement),
        ("Sample Fire Queries", test_sample_fire_queries)
    ]
    
    results = {}
    passed = 0
    total = len(tests)
    
    for test_name, test_function in tests:
        logger.info(f"\n📋 Running: {test_name}")
        try:
            result = test_function()
            results[test_name] = result
            if result:
                passed += 1
                logger.info(f"✅ {test_name}: PASSED")
            else:
                logger.error(f"❌ {test_name}: FAILED")
        except Exception as e:
            logger.error(f"❌ {test_name}: ERROR - {e}")
            results[test_name] = False
    
    logger.info("\n" + "=" * 60)
    logger.info(f"🎯 Test Results: {passed}/{total} PASSED")
    
    if passed == total:
        logger.info("🎉 All fire tools tests PASSED!")
        logger.info("✅ Fire data integration is working correctly")
    else:
        logger.error("❌ Some tests failed - check implementation")
    
    return results

def main():
    """Main test execution"""
    # Set up test environment
    os.environ.setdefault('BQ_PROJECT_ID', 'test_project')
    os.environ.setdefault('BQ_DATASET_ID', 'test_dataset')
    
    results = run_standalone_tests()
    
    # Exit with appropriate code
    all_passed = all(results.values())
    
    if all_passed:
        logger.info("\n🎉 POC-AD-1 Database Agent Enhancement: READY FOR PRODUCTION!")
        logger.info("✅ Fire data integration tools validated successfully")
    else:
        logger.error("\n❌ Issues found in fire integration - requires fixes")
    
    sys.exit(0 if all_passed else 1)

if __name__ == "__main__":
    main() 