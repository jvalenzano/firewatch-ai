#!/usr/bin/env python3
"""
POC-AD-1: Test Fire Data Integration with Database Agent
Tests the enhanced Database Agent with fire data capabilities
"""

import os
import sys
import logging
from pathlib import Path
from typing import Dict, List

# Add agent path for imports
agent_path = Path(__file__).parent.parent.parent.parent
sys.path.append(str(agent_path))

from data_science.sub_agents.bigquery.fire_tools import (
    get_fire_database_settings,
    get_fire_query_templates,
    format_fire_query,
    get_fire_query_suggestions,
    enhance_database_settings_with_fire_data
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FireIntegrationTester:
    """Test fire data integration with Database Agent"""
    
    def __init__(self):
        self.test_results = {}
        
    def test_fire_settings_loading(self) -> bool:
        """Test fire database settings loading"""
        logger.info("🧪 Testing fire database settings loading...")
        
        try:
            settings = get_fire_database_settings()
            
            required_keys = ['fire_project_id', 'fire_dataset_id', 'fire_tables', 'fire_schema', 'fire_enabled']
            
            for key in required_keys:
                if key not in settings:
                    logger.error(f"❌ Missing required key: {key}")
                    return False
            
            logger.info(f"✅ Fire settings loaded successfully")
            logger.info(f"   Dataset: {settings['fire_dataset_id']}")
            logger.info(f"   Tables: {len(settings['fire_tables'])}")
            logger.info(f"   Fire Enabled: {settings['fire_enabled']}")
            
            if settings['fire_enabled']:
                logger.info(f"   Schema Length: {len(settings['fire_schema'])} characters")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Fire settings loading failed: {e}")
            return False
    
    def test_query_templates(self) -> bool:
        """Test fire query templates"""
        logger.info("🧪 Testing fire query templates...")
        
        try:
            templates = get_fire_query_templates()
            
            expected_templates = [
                'all_stations', 'high_risk_stations', 'stations_by_state',
                'latest_fire_danger', 'extreme_fire_danger', 'fire_danger_trends',
                'weather_fire_correlation', 'dry_conditions_analysis',
                'fuel_moisture_analysis', 'geographic_fire_risk_summary'
            ]
            
            for template_name in expected_templates:
                if template_name not in templates:
                    logger.error(f"❌ Missing template: {template_name}")
                    return False
                
                # Test template formatting
                query = format_fire_query(template_name, "test_project")
                if "{project}" in query:
                    logger.error(f"❌ Template {template_name} not properly formatted")
                    return False
                
                logger.info(f"✅ Template {template_name}: {len(query)} chars")
            
            logger.info(f"✅ All {len(expected_templates)} query templates working")
            return True
            
        except Exception as e:
            logger.error(f"❌ Query template testing failed: {e}")
            return False
    
    def test_query_suggestions(self) -> bool:
        """Test fire query suggestions based on user intent"""
        logger.info("🧪 Testing fire query suggestions...")
        
        test_cases = [
            ("show me all weather stations", ['all_stations', 'stations_by_state']),
            ("what's the current fire danger?", ['latest_fire_danger', 'extreme_fire_danger', 'fire_danger_trends']),
            ("high elevation fire risk", ['high_risk_stations']),
            ("weather and fire correlation", ['weather_fire_correlation', 'dry_conditions_analysis']),
            ("fuel moisture analysis", ['fuel_moisture_analysis']),
            ("regional fire risk summary", ['geographic_fire_risk_summary', 'stations_by_state'])
        ]
        
        try:
            for user_query, expected_suggestions in test_cases:
                suggestions = get_fire_query_suggestions(user_query)
                
                # Check if at least one expected suggestion is present
                found_match = any(suggestion in suggestions for suggestion in expected_suggestions)
                
                if found_match:
                    logger.info(f"✅ '{user_query}' → {suggestions}")
                else:
                    logger.warning(f"⚠️ '{user_query}' → {suggestions} (expected one of {expected_suggestions})")
            
            logger.info("✅ Query suggestion testing complete")
            return True
            
        except Exception as e:
            logger.error(f"❌ Query suggestion testing failed: {e}")
            return False
    
    def test_database_enhancement(self) -> bool:
        """Test database settings enhancement with fire data"""
        logger.info("🧪 Testing database settings enhancement...")
        
        try:
            # Mock existing database settings
            existing_settings = {
                "bq_project_id": "test_project",
                "bq_dataset_id": "test_dataset",
                "bq_ddl_schema": "-- Existing schema\nCREATE TABLE test_table (id INT64);"
            }
            
            # Enhance with fire data
            enhanced_settings = enhance_database_settings_with_fire_data(existing_settings)
            
            # Check enhancement
            if 'fire_enabled' not in enhanced_settings:
                logger.error("❌ Fire settings not added to enhanced settings")
                return False
            
            if 'combined_schema' not in enhanced_settings:
                logger.error("❌ Combined schema not created")
                return False
            
            # Check schema combination
            combined_schema = enhanced_settings['combined_schema']
            if "-- Existing schema" not in combined_schema:
                logger.error("❌ Original schema not preserved")
                return False
            
            if enhanced_settings['fire_enabled'] and "FIRE RISK DATA TABLES" not in combined_schema:
                logger.warning("⚠️ Fire schema not included (fire data may not be available)")
            
            logger.info("✅ Database enhancement working correctly")
            logger.info(f"   Enhanced keys: {len(enhanced_settings)}")
            logger.info(f"   Combined schema: {len(combined_schema)} characters")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Database enhancement testing failed: {e}")
            return False
    
    def test_fire_query_examples(self) -> bool:
        """Test example fire queries for validity"""
        logger.info("🧪 Testing fire query examples...")
        
        try:
            templates = get_fire_query_templates()
            project_id = "test_project"
            
            # Test key queries
            test_queries = [
                'all_stations',
                'latest_fire_danger', 
                'extreme_fire_danger',
                'weather_fire_correlation'
            ]
            
            for query_name in test_queries:
                query = format_fire_query(query_name, project_id)
                
                # Basic SQL validation
                if not query.strip().upper().startswith('SELECT'):
                    logger.error(f"❌ Query {query_name} doesn't start with SELECT")
                    return False
                
                if 'poc_fire_data' not in query:
                    logger.error(f"❌ Query {query_name} doesn't reference fire dataset")
                    return False
                
                if project_id not in query:
                    logger.error(f"❌ Query {query_name} doesn't include project ID")
                    return False
                
                logger.info(f"✅ Query {query_name}: Valid SQL structure")
            
            logger.info("✅ Fire query examples are valid")
            return True
            
        except Exception as e:
            logger.error(f"❌ Fire query example testing failed: {e}")
            return False
    
    def run_all_tests(self) -> Dict[str, bool]:
        """Run all fire integration tests"""
        logger.info("🚀 Starting fire data integration tests...")
        logger.info("=" * 60)
        
        tests = [
            ("Fire Settings Loading", self.test_fire_settings_loading),
            ("Query Templates", self.test_query_templates),
            ("Query Suggestions", self.test_query_suggestions),
            ("Database Enhancement", self.test_database_enhancement),
            ("Fire Query Examples", self.test_fire_query_examples)
        ]
        
        results = {}
        passed = 0
        total = len(tests)
        
        for test_name, test_function in tests:
            logger.info(f"\n📋 Running: {test_name}")
            try:
                result = test_function()
                results[test_name] = result
                if result:
                    passed += 1
                    logger.info(f"✅ {test_name}: PASSED")
                else:
                    logger.error(f"❌ {test_name}: FAILED")
            except Exception as e:
                logger.error(f"❌ {test_name}: ERROR - {e}")
                results[test_name] = False
        
        logger.info("\n" + "=" * 60)
        logger.info(f"🎯 Test Results: {passed}/{total} PASSED")
        
        if passed == total:
            logger.info("🎉 All fire integration tests PASSED!")
            logger.info("✅ Database Agent is ready for fire data queries")
        else:
            logger.error("❌ Some tests failed - check implementation")
        
        return results

def main():
    """Main test execution"""
    # Set up test environment
    os.environ.setdefault('BQ_PROJECT_ID', 'test_project')
    os.environ.setdefault('BQ_DATASET_ID', 'test_dataset')
    
    tester = FireIntegrationTester()
    results = tester.run_all_tests()
    
    # Exit with appropriate code
    all_passed = all(results.values())
    sys.exit(0 if all_passed else 1)

if __name__ == "__main__":
    main() 